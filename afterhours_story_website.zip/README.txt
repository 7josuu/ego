AFTERHOURS — STORY WEBSITE
==========================
Website untuk menulis kisah hidup seperti artikel/buku digital. Setiap cerita
memiliki judul, tanggal, isi panjang, dan foto opsional. Cerita tampil sebagai
kumpulan artikel dan dapat dibuka untuk dibaca penuh.

FILE
- index.html: website
- supabase_setup.sql: database, aturan akses pribadi, dan bucket foto
- README.txt: panduan

AGAR ONLINE DAN BISA DIAKSES DARI SEMUA PERANGKAT
1. Buat project di https://supabase.com/
2. Buka SQL Editor > New query. Salin semua isi supabase_setup.sql dan tekan Run.
3. Buka Project Settings > API / Connect. Salin Project URL dan anon/public/
   publishable key. Jangan gunakan service_role/secret key.
4. Deploy index.html ke hosting HTTPS seperti https://www.netlify.com/ atau
   https://vercel.com/. Kamu bisa membuat akun dan deploy melalui dashboard.
5. Buka alamat website hasil deploy. Pada layar awal, masukkan Project URL dan
   anon/publishable key. Konfigurasi tersimpan di browser itu.
6. Daftar dengan email dan password. Gunakan akun yang sama saat membuka web
   dari perangkat lain. Jika konfirmasi email aktif, konfirmasi email dulu.

PRIVASI
- Database memakai Row Level Security sehingga user hanya dapat mengakses
  cerita milik user_id sendiri.
- Foto disimpan di bucket privat. Website membuat signed URL sementara untuk
  menampilkan foto. Signed URL berlaku 1 jam dan dibuat ulang saat data dimuat.
- Jangan pernah memasukkan service_role key ke website.
- Batasi akses dengan akun dan password. Jangan membagikan akun.
- Foto maksimal 8 MB, JPEG/PNG/WebP/GIF.
- Website belum dipublikasikan dan belum terhubung ke project Supabase milikmu.
