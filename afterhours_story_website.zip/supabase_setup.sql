-- Supabase SQL Editor: jalankan seluruh script ini satu kali.
create table if not exists public.diary_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text default '',
  body text default '',
  entry_date date not null default current_date,
  photo_path text,
  created_at timestamptz not null default now()
);
alter table public.diary_entries enable row level security;
drop policy if exists "Users read own stories" on public.diary_entries;
create policy "Users read own stories" on public.diary_entries for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users insert own stories" on public.diary_entries;
create policy "Users insert own stories" on public.diary_entries for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users update own stories" on public.diary_entries;
create policy "Users update own stories" on public.diary_entries for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "Users delete own stories" on public.diary_entries;
create policy "Users delete own stories" on public.diary_entries for delete to authenticated using (auth.uid() = user_id);

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('diary-photos','diary-photos',false,8388608,array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public=false,file_size_limit=8388608;

drop policy if exists "Story owners read photos" on storage.objects;
create policy "Story owners read photos" on storage.objects for select to authenticated using (bucket_id='diary-photos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Story owners upload photos" on storage.objects;
create policy "Story owners upload photos" on storage.objects for insert to authenticated with check (bucket_id='diary-photos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Story owners update photos" on storage.objects;
create policy "Story owners update photos" on storage.objects for update to authenticated using (bucket_id='diary-photos' and (storage.foldername(name))[1]=auth.uid()::text) with check (bucket_id='diary-photos' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "Story owners delete photos" on storage.objects;
create policy "Story owners delete photos" on storage.objects for delete to authenticated using (bucket_id='diary-photos' and (storage.foldername(name))[1]=auth.uid()::text);
